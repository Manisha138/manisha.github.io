import base64
import mimetypes

from flask import Flask, jsonify, request
from flask_cors import CORS

app = Flask(__name__)
CORS(app, resources={r"/bfhl": {"origins": "*"}})

def is_base64_valid(base64_string):
    try:
        base64.b64decode(base64_string, validate=True)
        return True                                                                                                                       
    except Exception:
        return False

def extract_data(data):
    numbers = [item for item in data if isinstance(item, str) and item.isdigit()]
    alphabets = [item for item in data if isinstance(item, str) and item.isalpha()]
    lowest_lowercase = min([ch for ch in data if ch.islower()], default=None)
    highest_lowercase = [max([ch for ch in data if ch.islower()], default=None)] if any(ch.islower() for ch in data) else []
    return numbers, alphabets, highest_lowercase

@app.route('/bfhl', methods=['POST'])
def process_data():
    # Validate JSON request
    if not request.is_json:
        return jsonify({"is_success": False, "error": "Invalid input, expected JSON format"}), 400

    data = request.json.get("data", [])
    file_b64 = request.json.get("file_b64", "")

    if not isinstance(data, list):
        return jsonify({"is_success": False, "error": "Invalid data format, expected a list"}), 400

    # Debugging output
    print("Received data:", data)
    print("Received file_b64:", file_b64)

    numbers, alphabets, highest_lowercase = extract_data(data)

    # File handling
    file_valid = is_base64_valid(file_b64)
    file_mime_type = "unknown"
    file_size_kb = 0

    if file_valid:
        try:
            decoded_file = base64.b64decode(file_b64)
            file_size_kb = len(decoded_file) / 1024
            # Here, you might want to pass a filename or detect MIME type more accurately
            file_mime_type = mimetypes.guess_type('file')[0] or 'application/octet-stream'
        except Exception as e:
            print("Error decoding file:", e)
            file_valid = False

    response = {
        "is_success": True,
        "user_id": "manisha_dubey_13032004",
        "email": "mk8645@srmist.edu.in",
        "roll_number": "RA2111003020454",
        "numbers": numbers,
        "alphabets": alphabets,
        "highest_lowercase_alphabet": highest_lowercase,
        "file_valid": file_valid,
        "file_mime_type": file_mime_type,
        "file_size_kb": f"{file_size_kb:.2f}"
    }

    return jsonify(response)

@app.route('/bfhl', methods=['GET'])
def get_operation_code():
    return jsonify({"operation_code": 1}), 200

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3000)
