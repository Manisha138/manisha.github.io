import React, { useState, useEffect } from 'react';
import './App.css';

function App() {
  const [jsonInput, setJsonInput] = useState('');
  const [response, setResponse] = useState(null);
  const [error, setError] = useState('');
  const [selectedOptions, setSelectedOptions] = useState([]);
  const [isJsonValid, setIsJsonValid] = useState(false);

  // Set the website title to your roll number
  useEffect(() => {
    document.title = 'RA2111003020454';
  }, []);

  const handleInputChange = (event) => {
    setJsonInput(event.target.value);
  };

  const handleOptionChange = (event) => {
    const options = Array.from(event.target.selectedOptions, (option) => option.value);
    setSelectedOptions(options);
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError('');
    setResponse(null);
    setSelectedOptions([]);
    setIsJsonValid(false);

    try {
      const parsedJson = JSON.parse(jsonInput);
      if (!parsedJson.data || !Array.isArray(parsedJson.data)) {
        throw new Error('Invalid input: "data" field must be an array');
      }

      const response = await fetch('https://c1f18acc-b663-49bd-aa18-860aa35e0504-00-1goty3crjz5c7.sisko.replit.dev:3000/bfhl', { // Adjust the backend URL as needed
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(parsedJson),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'An error occurred');
      }

      const data = await response.json();
      setResponse(data);
      setIsJsonValid(true);  // Mark JSON as valid once response is received
    } catch (error) {
      setError(error.message);
    }
  };

  // Render the filtered response based on the selected options
  const renderFilteredResponse = () => {
    if (!response) return null;

    const filteredSections = [];

    if (selectedOptions.includes('numbers') && response.numbers.length > 0) {
      filteredSections.push({
        title: 'Numbers',
        content: response.numbers.join(', '),  // Display horizontally
      });
    }

    if (selectedOptions.includes('alphabets') && response.alphabets.length > 0) {
      filteredSections.push({
        title: 'Alphabets',
        content: response.alphabets.join(', '),  // Display horizontally
      });
    }

    if (selectedOptions.includes('highest_lowercase_alphabet') && response.highest_lowercase_alphabet.length > 0) {
      filteredSections.push({
        title: 'Highest Lowercase Alphabet',
        content: response.highest_lowercase_alphabet.join(', '),  // Display horizontally
      });
    }

    if (filteredSections.length === 0) {
      return <p>No data to display based on selected filters.</p>;
    }

    return (
      <div className="filtered-response">
        {filteredSections.map((section, index) => (
          <div key={index} style={{ marginBottom: '10px' }}>
            <h4>{section.title}:</h4>
            <p>{section.content}</p>  {/* Display horizontally in paragraph */}
          </div>
        ))}
      </div>
    );
  };

  return (
    <div className="App">
      <h1>RA2111003020454</h1>
      <form onSubmit={handleSubmit}>
        <label>
          Enter JSON Input:
          <textarea
            value={jsonInput}
            onChange={handleInputChange}
            placeholder='{"data": ["A", "B", "1", "2", "z"]}'
            rows="6"
            cols="50"
            className="input-field"
          />
        </label>
        <br />
        <button type="submit" className="submit-btn">Submit</button>
      </form>

      {error && <p style={{ color: 'red' }}>{error}</p>}

      {/* Render the multi-select dropdown only after valid JSON submission */}
      {isJsonValid && response && (
        <>
          <label>
            <h4>Multi Filter</h4>
            <select multiple={true} onChange={handleOptionChange} className="filter-select">
              <option value="numbers">Numbers</option>
              <option value="alphabets">Alphabets</option>
              <option value="highest_lowercase_alphabet">Highest Lowercase Alphabet</option>
            </select>
          </label>

          {/* Display only the filtered response */}
          {selectedOptions.length > 0 && renderFilteredResponse()}
        </>
      )}
    </div>
  );
}

export default App;







